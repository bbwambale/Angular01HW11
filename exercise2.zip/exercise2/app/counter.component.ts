import { Component, OnInit, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-counter',
  outputs:['counterChange'],
  template: `
<button (click)="decreament()">-</button>
<span>{{counterValue}}</span>
<button (click)="increament()">+</button>
  `,
  styles: [],
  inputs:['counterInput']
})
export class CounterComponent {
   onclickOutput:EventEmitter<Number>;
    counterValue: number = 0;
    counterInput: number = 0;

  constructor() {
    this.onclickOutput= new EventEmitter;
   }

  decreament(){
    this.onclickOutput.emit(--this.counterValue);
    return false;
  }

  increament(){
    this.onclickOutput.emit(++this.counterValue);
    return false;
  }
}
